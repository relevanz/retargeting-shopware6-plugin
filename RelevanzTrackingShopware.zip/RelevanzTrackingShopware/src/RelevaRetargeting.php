<?php declare(strict_types=1);

namespace Releva\Retargeting\Shopware;

use Shopware\Core\Framework\Plugin;

class RelevaRetargeting extends Plugin
{
}
