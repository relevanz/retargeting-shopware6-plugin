import RelevanzRetargetingUtil from './utility/relevanz-retargeting/relevanz-retargeting.util';
export default new RelevanzRetargetingUtil();