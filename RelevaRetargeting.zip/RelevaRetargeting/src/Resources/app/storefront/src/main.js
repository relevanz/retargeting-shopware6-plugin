import RelevanzRetargetingUtil from './utility/relevanz-retargeting/relevanz-retargeting.util';
new RelevanzRetargetingUtil();