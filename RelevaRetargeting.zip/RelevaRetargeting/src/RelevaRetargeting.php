<?php declare(strict_types=1);

namespace Releva\Retargeting\Shopware;

use Shopware\Core\Framework\Plugin;

!file_exists(dirname(__DIR__) . '/vendor/autoload.php') || require dirname(__DIR__) . '/vendor/autoload.php';//@todo test with composer requiere

class RelevaRetargeting extends Plugin
{
}
