<?php declare(strict_types=1);

namespace Releva\Retargeting\Shopware;

use Shopware\Core\Framework\Plugin;

!file_exists(dirname(__DIR__) . '/vendor/autoload.php') || require_once dirname(__DIR__) . '/vendor/autoload.php';

class RelevaRetargeting extends Plugin
{
}
